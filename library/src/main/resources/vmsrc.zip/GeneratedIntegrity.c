#include "vm/include/vm.h"

#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <sys/resource.h>
#include <time.h>

__attribute__((used, section(".data.wexhash"), aligned(16384)))
static u1 EXPECTED_GENERATED_HASH_PAGE[16384] = {
        0x71, 0x3c, 0xa9, 0x52, 0xe6, 0x18, 0x4d, 0xbf,
        0x90, 0x27, 0x65, 0xda, 0x43, 0xbc, 0x0f, 0x81,
        0x5e, 0xd4, 0x39, 0xa7, 0xc2, 0x68, 0xf1, 0x0b,
        0x96, 0x54, 0x2d, 0xe3, 0x7a, 0xc8, 0x11, 0x6f
};

static _Atomic u8 g_generated_delta = 0;
static _Atomic int g_generated_worker_started = 0;

u8 nmmp_integrity_delta(void);

static void generated_sleep_ms(unsigned delay_ms) {
    struct timespec delay = {
            .tv_sec = (time_t) (delay_ms / 1000u),
            .tv_nsec = (long) (delay_ms % 1000u) * 1000000L
    };
    while (nanosleep(&delay, &delay) != 0 && errno == EINTR) {}
}

static void *generated_integrity_worker(void *unused) {
    (void) unused;
    // Android implements nice values per kernel task, so this only lowers the
    // verifier thread. UI/JNI callers never hash the multi-megabyte text segment.
    (void) setpriority(PRIO_PROCESS, 0, 15);
    generated_sleep_ms(1200u + (0x6d2b79f5u /*WXROOTSCHED*/ & 0x3ffu));

    for (;;) {
        if (atomic_load_explicit(&g_generated_delta, memory_order_acquire) != 0) {
            return NULL;
        }
        const u8 delta = vm_verify_module(
                (const void *) &nmmp_integrity_delta, EXPECTED_GENERATED_HASH_PAGE);
        if (delta != 0) {
            atomic_store_explicit(&g_generated_delta, delta, memory_order_release);
            return NULL;
        }
        generated_sleep_ms(30000u + (0x6d2b79f5u /*WXROOTSCHED*/ & 0x1fffu));
    }
}

static void ensure_generated_integrity_worker(void) {
    int expected = 0;
    if (!atomic_compare_exchange_strong_explicit(
            &g_generated_worker_started, &expected, 1,
            memory_order_acq_rel, memory_order_acquire)) {
        return;
    }
    pthread_t worker;
    if (pthread_create(&worker, NULL, generated_integrity_worker, NULL) == 0) {
        (void) pthread_detach(worker);
    } else {
        // A later JNI call retries if the process temporarily cannot create a thread.
        atomic_store_explicit(&g_generated_worker_started, 0, memory_order_release);
    }
}

u8 nmmp_integrity_delta(void) {
    ensure_generated_integrity_worker();
    return atomic_load_explicit(&g_generated_delta, memory_order_acquire);
}
