#include "Crypto.h"
#include "vm.h"

#include <cstring>

extern "C" void vm_get_kdf_root(u1 out[32]);

namespace {

constexpr u4 SHA_K[64] = {
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

constexpr u1 KDF_LABEL[] = {'N','M','M','P','-','A','E','A','D','-','K','D','F','2'};
constexpr u1 TAG_LABEL[] = {'N','M','M','P','-','A','E','A','D','-','T','A','G','2'};

static inline u4 rotr32(u4 value, unsigned shift) {
    return (value >> shift) | (value << (32u - shift));
}

static inline u4 rotl32(u4 value, unsigned shift) {
    return (value << shift) | (value >> (32u - shift));
}

static inline u8 rotl64(u8 value, unsigned shift) {
    return (value << shift) | (value >> (64u - shift));
}

static inline u4 load32le(const u1 *p) {
    return (u4) p[0] | ((u4) p[1] << 8) | ((u4) p[2] << 16) | ((u4) p[3] << 24);
}

static inline void store32le(u1 *p, u4 value) {
    p[0] = (u1) value;
    p[1] = (u1) (value >> 8);
    p[2] = (u1) (value >> 16);
    p[3] = (u1) (value >> 24);
}

static inline void store64le(u1 *p, u8 value) {
    for (unsigned i = 0; i < 8; i++) p[i] = (u1) (value >> (i * 8));
}

static void sha_transform(VmSha256 *s, const u1 block[64]) {
    u4 w[64];
    for (int i = 0; i < 16; i++) {
        const u1 *p = block + i * 4;
        w[i] = ((u4) p[0] << 24) | ((u4) p[1] << 16) | ((u4) p[2] << 8) | p[3];
    }
    for (int i = 16; i < 64; i++) {
        const u4 a = w[i - 15], b = w[i - 2];
        const u4 s0 = rotr32(a, 7) ^ rotr32(a, 18) ^ (a >> 3);
        const u4 s1 = rotr32(b, 17) ^ rotr32(b, 19) ^ (b >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    u4 a = s->h[0], b = s->h[1], c = s->h[2], d = s->h[3];
    u4 e = s->h[4], f = s->h[5], g = s->h[6], h = s->h[7];
    for (int i = 0; i < 64; i++) {
        const u4 s1 = rotr32(e, 6) ^ rotr32(e, 11) ^ rotr32(e, 25);
        const u4 ch = (e & f) ^ (~e & g);
        const u4 t1 = h + s1 + ch + SHA_K[i] + w[i];
        const u4 s0 = rotr32(a, 2) ^ rotr32(a, 13) ^ rotr32(a, 22);
        const u4 maj = (a & b) ^ (a & c) ^ (b & c);
        const u4 t2 = s0 + maj;
        h = g; g = f; f = e; e = d + t1;
        d = c; c = b; b = a; a = t1 + t2;
    }
    s->h[0] += a; s->h[1] += b; s->h[2] += c; s->h[3] += d;
    s->h[4] += e; s->h[5] += f; s->h[6] += g; s->h[7] += h;
    vm_secure_zero(w, sizeof(w));
}

struct HmacSha256 {
    VmSha256 inner;
    u1 outerPad[64];
};

static void hmac_init(HmacSha256 *ctx, const u1 *key, size_t keySize) {
    u1 normalized[64]{};
    if (keySize > 64) {
        vm_sha256(key, keySize, normalized);
    } else if (keySize != 0) {
        memcpy(normalized, key, keySize);
    }
    u1 innerPad[64];
    for (size_t i = 0; i < sizeof(innerPad); i++) {
        innerPad[i] = normalized[i] ^ 0x36u;
        ctx->outerPad[i] = normalized[i] ^ 0x5cu;
    }
    vm_sha256_init(&ctx->inner);
    vm_sha256_update(&ctx->inner, innerPad, sizeof(innerPad));
    vm_secure_zero(normalized, sizeof(normalized));
    vm_secure_zero(innerPad, sizeof(innerPad));
}

static void hmac_update(HmacSha256 *ctx, const void *data, size_t size) {
    vm_sha256_update(&ctx->inner, data, size);
}

static void hmac_final(HmacSha256 *ctx, u1 out[32]) {
    u1 innerDigest[32];
    vm_sha256_final(&ctx->inner, innerDigest);
    VmSha256 outer;
    vm_sha256_init(&outer);
    vm_sha256_update(&outer, ctx->outerPad, sizeof(ctx->outerPad));
    vm_sha256_update(&outer, innerDigest, sizeof(innerDigest));
    vm_sha256_final(&outer, out);
    vm_secure_zero(innerDigest, sizeof(innerDigest));
    vm_secure_zero(ctx, sizeof(*ctx));
}

static void hmac(const u1 *key, size_t keySize,
                 const void *data, size_t dataSize, u1 out[32]) {
    HmacSha256 ctx{};
    hmac_init(&ctx, key, keySize);
    hmac_update(&ctx, data, dataSize);
    hmac_final(&ctx, out);
}

static void quarter_round(u4 &a, u4 &b, u4 &c, u4 &d) {
    a += b; d ^= a; d = rotl32(d, 16);
    c += d; b ^= c; b = rotl32(b, 12);
    a += b; d ^= a; d = rotl32(d, 8);
    c += d; b ^= c; b = rotl32(b, 7);
}

static void chacha_block(const u1 key[32], u4 counter, const u1 nonce[12], u1 output[64]) {
    u4 state[16] = {
            0x61707865u, 0x3320646eu, 0x79622d32u, 0x6b206574u,
            load32le(key), load32le(key + 4), load32le(key + 8), load32le(key + 12),
            load32le(key + 16), load32le(key + 20), load32le(key + 24), load32le(key + 28),
            counter, load32le(nonce), load32le(nonce + 4), load32le(nonce + 8)
    };
    u4 working[16];
    memcpy(working, state, sizeof(state));
    for (int i = 0; i < 10; i++) {
        quarter_round(working[0], working[4], working[8], working[12]);
        quarter_round(working[1], working[5], working[9], working[13]);
        quarter_round(working[2], working[6], working[10], working[14]);
        quarter_round(working[3], working[7], working[11], working[15]);
        quarter_round(working[0], working[5], working[10], working[15]);
        quarter_round(working[1], working[6], working[11], working[12]);
        quarter_round(working[2], working[7], working[8], working[13]);
        quarter_round(working[3], working[4], working[9], working[14]);
    }
    for (int i = 0; i < 16; i++) store32le(output + i * 4, working[i] + state[i]);
    vm_secure_zero(state, sizeof(state));
    vm_secure_zero(working, sizeof(working));
}

static void chacha_xor(u1 *dst, const u1 *src, size_t size,
                       const u1 key[32], const u1 nonce[12]) {
    u4 counter = 1;
    u1 block[64];
    while (size != 0) {
        chacha_block(key, counter++, nonce, block);
        const size_t count = size < sizeof(block) ? size : sizeof(block);
        for (size_t i = 0; i < count; i++) dst[i] = src[i] ^ block[i];
        dst += count;
        src += count;
        size -= count;
    }
    vm_secure_zero(block, sizeof(block));
}

static void derive_keys(u4 domain, u8 contextTag, u8 siteMaterial,
                        u1 encryptionKey[32], u1 authenticationKey[32]) {
    u1 root[32];
    vm_get_kdf_root(root);

    u8 runtimeMaterial = vm_sig_key();
    const u8 nativeDelta = vm_integrity_delta();
    const u8 dexDelta = vm_dex_integrity_delta();
    runtimeMaterial ^= rotl64(nativeDelta, 13) ^ rotl64(dexDelta, 29);

    u1 input[sizeof(KDF_LABEL) + 8 + 4 + 8 + 8 + 1];
    size_t offset = 0;
    memcpy(input + offset, KDF_LABEL, sizeof(KDF_LABEL)); offset += sizeof(KDF_LABEL);
    store64le(input + offset, runtimeMaterial); offset += 8;
    store32le(input + offset, domain); offset += 4;
    store64le(input + offset, contextTag); offset += 8;
    store64le(input + offset, siteMaterial); offset += 8;
    input[offset] = 1;
    hmac(root, sizeof(root), input, sizeof(input), encryptionKey);
    input[offset] = 2;
    hmac(root, sizeof(root), input, sizeof(input), authenticationKey);
    vm_secure_zero(root, sizeof(root));
    vm_secure_zero(input, sizeof(input));
}

static void authentication_tag(const u1 key[32], u4 domain,
                               u8 contextTag, u8 siteMaterial,
                               const u1 nonce[12], const u1 *ciphertext,
                               size_t size, u1 out[32]) {
    HmacSha256 hmacState{};
    hmac_init(&hmacState, key, 32);
    hmac_update(&hmacState, TAG_LABEL, sizeof(TAG_LABEL));
    u1 metadata[4 + 8 + 8];
    store32le(metadata, domain);
    store64le(metadata + 4, contextTag);
    store64le(metadata + 12, siteMaterial);
    hmac_update(&hmacState, metadata, sizeof(metadata));
    hmac_update(&hmacState, nonce, 12);
    u1 length[8];
    store64le(length, (u8) size);
    hmac_update(&hmacState, length, sizeof(length));
    hmac_update(&hmacState, ciphertext, size);
    hmac_final(&hmacState, out);
    vm_secure_zero(metadata, sizeof(metadata));
    vm_secure_zero(length, sizeof(length));
}

static bool constant_time_equal_16(const u1 a[16], const u1 b[16]) {
    u4 difference = 0;
    for (size_t i = 0; i < 16; i++) difference |= (u4) (a[i] ^ b[i]);
    return difference == 0;
}

} // namespace

void vm_secure_zero(void *data, size_t size) {
    volatile u1 *cursor = reinterpret_cast<volatile u1 *>(data);
    while (size-- != 0) *cursor++ = 0;
}

void vm_sha256_init(VmSha256 *s) {
    const u4 initial[8] = {
            0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
            0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    };
    memcpy(s->h, initial, sizeof(initial));
    s->bits = 0;
    s->used = 0;
}

void vm_sha256_update(VmSha256 *s, const void *input, size_t size) {
    const auto *data = reinterpret_cast<const u1 *>(input);
    s->bits += (u8) size * 8u;
    while (size != 0) {
        const size_t space = sizeof(s->block) - s->used;
        const size_t take = size < space ? size : space;
        memcpy(s->block + s->used, data, take);
        s->used += take;
        data += take;
        size -= take;
        if (s->used == sizeof(s->block)) {
            sha_transform(s, s->block);
            s->used = 0;
        }
    }
}

void vm_sha256_final(VmSha256 *s, u1 out[32]) {
    s->block[s->used++] = 0x80;
    if (s->used > 56) {
        while (s->used < 64) s->block[s->used++] = 0;
        sha_transform(s, s->block);
        s->used = 0;
    }
    while (s->used < 56) s->block[s->used++] = 0;
    for (int i = 7; i >= 0; i--) s->block[s->used++] = (u1) (s->bits >> (i * 8));
    sha_transform(s, s->block);
    for (int i = 0; i < 8; i++) {
        out[i * 4] = (u1) (s->h[i] >> 24);
        out[i * 4 + 1] = (u1) (s->h[i] >> 16);
        out[i * 4 + 2] = (u1) (s->h[i] >> 8);
        out[i * 4 + 3] = (u1) s->h[i];
    }
    vm_secure_zero(s, sizeof(*s));
}

void vm_sha256(const void *data, size_t size, u1 out[32]) {
    VmSha256 state{};
    vm_sha256_init(&state);
    vm_sha256_update(&state, data, size);
    vm_sha256_final(&state, out);
}

extern "C" __attribute__((visibility("default")))
bool vm_aead_open(u1 *dst, const u1 *src, u4 size,
                  const u1 nonce[12], const u1 expectedTag[16],
                  u4 domain, u8 contextTag, u8 siteMaterial) {
    u1 encryptionKey[32];
    u1 authenticationKey[32];
    u1 actualTag[32];
    derive_keys(domain, contextTag, siteMaterial, encryptionKey, authenticationKey);
    authentication_tag(authenticationKey, domain, contextTag, siteMaterial,
                       nonce, src, size, actualTag);
    const bool valid = constant_time_equal_16(actualTag, expectedTag);
    if (valid) {
        chacha_xor(dst, src, size, encryptionKey, nonce);
    } else if (dst != nullptr && size != 0) {
        vm_secure_zero(dst, size);
    }
    vm_secure_zero(encryptionKey, sizeof(encryptionKey));
    vm_secure_zero(authenticationKey, sizeof(authenticationKey));
    vm_secure_zero(actualTag, sizeof(actualTag));
    return valid;
}
