//
// Build-time key derivation from APK signing block.
//
#include "Common.h"

#include <atomic>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/syscall.h>
#include <sched.h>

// Compatibility macros for syscall numbers across NDK unified headers & ABIs (ARM32/ARM64/x86/x86_64)
#ifndef SYS_openat
  #ifdef __NR_openat
    #define SYS_openat __NR_openat
  #else
    #define SYS_openat 56
  #endif
#endif

#ifndef SYS_pread64
  #ifdef __NR_pread64
    #define SYS_pread64 __NR_pread64
  #elif defined(__arm__)
    #define SYS_pread64 180
  #else
    #define SYS_pread64 67
  #endif
#endif

#ifndef SYS_read
  #ifdef __NR_read
    #define SYS_read __NR_read
  #else
    #define SYS_read 63
  #endif
#endif

#ifndef SYS_close
  #ifdef __NR_close
    #define SYS_close __NR_close
  #else
    #define SYS_close 57
  #endif
#endif

#ifndef SYS_lseek
  #ifdef __NR_lseek
    #define SYS_lseek __NR_lseek
  #else
    #define SYS_lseek 62
  #endif
#endif

// Per-build placeholders are replaced before native compilation. Salt halves
// are kept separate so there is no single embedded bytecode decryption key.
#define SIGNATURE_BINDING_ENABLED 7u /*SIGENABLED*/
#define SIG_SALT_0_LO 0x13579bdfu /*SIGS0L*/
#define SIG_SALT_0_HI 0x2468ace0u /*SIGS0H*/
#define SIG_SALT_1_LO 0x13579be0u /*SIGS1L*/
#define SIG_SALT_1_HI 0x2468ace1u /*SIGS1H*/
#define SIG_SALT_2_LO 0x13579be1u /*SIGS2L*/
#define SIG_SALT_2_HI 0x2468ace2u /*SIGS2H*/
#define SIG_SALT_3_LO 0x13579be2u /*SIGS3L*/
#define SIG_SALT_3_HI 0x2468ace3u /*SIGS3H*/

namespace {

// --- raw syscall file I/O (resists libc PLT/inline hooks on open/read) ---
static int sc_openat(const char *path) {
    int fd = (int) syscall(SYS_openat, AT_FDCWD, path, O_RDONLY, 0);
    if (fd >= 0) return fd;
    return open(path, O_RDONLY | O_CLOEXEC);
}
static long sc_pread(int fd, void *buf, unsigned long n, long off) {
    return syscall(SYS_pread64, fd, buf, n, off);
}
static long sc_read(int fd, void *buf, unsigned long n) {
    return syscall(SYS_read, fd, buf, n);
}
static void sc_close(int fd) { syscall(SYS_close, fd); }
static long sc_size(int fd) { return syscall(SYS_lseek, fd, 0, SEEK_END); }

// Read this process's base package name from /proc/self/cmdline.
static bool read_pkg(char *out, size_t outsz) {
    int fd = sc_openat("/proc/self/cmdline");
    if (fd < 0) return false;
    long r = sc_read(fd, out, (unsigned long) (outsz - 1));
    sc_close(fd);
    if (r <= 0) return false;
    out[r] = 0;
    for (long i = 0; i < r; i++) { if (out[i] == ':' || out[i] == 0) { out[i] = 0; break; } }
    return out[0] != 0;
}

static bool copy_fs_path(const char *src, char *dst, size_t dstsz) {
    if (!src || src[0] != '/') return false;
    size_t n = 0;
    while (src[n] != 0 && src[n] != ' ' && src[n] != '\t' && src[n] != '\r') n++;
    if (n == 0 || n + 1 > dstsz) return false;
    memcpy(dst, src, n);
    dst[n] = 0;
    return true;
}

static bool apk_from_native_lib(const char *so_path, char *path, size_t pathsz) {
    if (!so_path) return false;
    const char *lib = strstr(so_path, "/lib/");
    if (!lib) return false;
    size_t prefix = (size_t) (lib - so_path);
    if (prefix + sizeof("/base.apk") > pathsz) return false;
    memcpy(path, so_path, prefix);
    memcpy(path + prefix, "/base.apk", sizeof("/base.apk"));
    return true;
}

static void sigcheck_anchor() {}

static bool apk_from_dladdr(const char *fname, char *path, size_t pathsz) {
    if (!fname) return false;
    // extractNativeLibs=false: linker reports ".../base.apk" or ".../base.apk!/lib/..."
    const char *apk = strstr(fname, ".apk");
    if (apk) {
        size_t n = (size_t) (apk - fname) + 4;
        if (n + 1 > pathsz || fname[0] != '/') return false;
        memcpy(path, fname, n);
        path[n] = 0;
        return true;
    }
    return apk_from_native_lib(fname, path, pathsz);
}

static bool find_base_apk_from_self(char *path, size_t pathsz) {
    Dl_info info{};
    return dladdr(reinterpret_cast<void *>(&sigcheck_anchor), &info)
            && apk_from_dladdr(info.dli_fname, path, pathsz);
}

// Find base APK in /proc/self/maps matching the package name.
static bool find_base_apk(const char *pkg, char *path, size_t pathsz) {
    int fd = sc_openat("/proc/self/maps");
    if (fd < 0) return false;
    char buf[2048];
    size_t pending = 0;
    bool found = false;
    long r;
    while (!found && (r = sc_read(fd, buf + pending, sizeof(buf) - 1 - pending)) > 0) {
        size_t total = pending + (size_t) r;
        buf[total] = 0;
        size_t line_start = 0;
        for (size_t i = 0; i < total; i++) {
            if (buf[i] == '\n') {
                buf[i] = 0;
                const char *line = buf + line_start;
                const char *slash = strchr(line, '/');
                if (slash && strstr(slash, pkg)) {
                    if (strstr(slash, ".apk") && copy_fs_path(slash, path, pathsz)) {
                        found = true;
                        break;
                    }
                    if (strstr(slash, ".so") && apk_from_native_lib(slash, path, pathsz)) {
                        found = true;
                        break;
                    }
                }
                line_start = i + 1;
            }
        }
        if (line_start < total) {
            pending = total - line_start;
            memmove(buf, buf + line_start, pending);
        } else {
            pending = 0;
        }
    }
    sc_close(fd);
    return found;
}

struct [[maybe_unused]] ZipEocd {
    u4 sig;
    u2 disk;
    u2 cd_disk;
    u2 disk_entries;
    u2 total_entries;
    u4 cd_size;
    u4 cd_offset;
    u2 comment_len;
};

// Scan the end of the APK for the EOCD record.
static long find_eocd(int fd, long file_size) {
    size_t scan_size = file_size < 65557 ? (size_t) file_size : 65557;
    long search_start = file_size - (long) scan_size;
    u1 buf[4096];
    long pos = file_size - 4;
    while (pos >= search_start) {
        long chunk_off = pos - 4092;
        if (chunk_off < search_start) chunk_off = search_start;
        size_t chunk_len = (size_t) (pos + 4 - chunk_off);
        if (sc_pread(fd, buf, chunk_len, chunk_off) != (long) chunk_len) return -1;
        for (long i = (long) chunk_len - 4; i >= 0; i--) {
            if (buf[i] == 0x50 && buf[i + 1] == 0x4b && buf[i + 2] == 0x05 && buf[i + 3] == 0x06) {
                return chunk_off + i;
            }
        }
        pos = chunk_off - 1;
    }
    return -1;
}

static u4 read_u4_le(const u1 *p) {
    return (u4) p[0] | ((u4) p[1] << 8) | ((u4) p[2] << 16) | ((u4) p[3] << 24);
}
static u8 read_u8_le(const u1 *p) {
    return (u8) read_u4_le(p) | ((u8) read_u4_le(p + 4) << 32);
}

// Locate APK Signing Block v2/v3 magic ("APK Sig Block 42") and parse cert fold.
static bool find_sig_block(int fd, long eocd_off, long *out_block_off, u8 *out_block_size) {
    // EOCD is 22 bytes; a no-comment APK ends exactly there. Reading 24
    // bytes fails pread (short read) and looked like a missing signing block.
    u1 buf[22];
    if (sc_pread(fd, buf, 22, eocd_off) != 22) return false;
    u4 cd_offset = read_u4_le(buf + 16);
    if (cd_offset < 32) return false;

    u1 header[24];
    long search_off = (long) cd_offset - 24;
    if (sc_pread(fd, header, 24, search_off) != 24) return false;
    static const u1 MAGIC[16] = {
            'A', 'P', 'K', ' ', 'S', 'i', 'g', ' ', 'B', 'l', 'o', 'c', 'k', ' ', '4', '2'
    };
    if (memcmp(header + 8, MAGIC, 16) != 0) return false;
    u8 size_in_header = read_u8_le(header);
    if (size_in_header < 32 || size_in_header > (u8) cd_offset) return false;
    *out_block_off = (long) cd_offset - 8 - (long) size_in_header;
    *out_block_size = size_in_header;
    return true;
}

// Extract first X.509 cert bytes from APK signing block payload and fold it to u8.
static u8 parse_cert_fold(int fd, long block_off, u8 block_size) {
    if (block_size < 32 || block_size > 8 * 1024 * 1024) return 0;
    u1 *buf = (u1 *) malloc((size_t) block_size);
    if (!buf) return 0;
    if (sc_pread(fd, buf, (unsigned long) block_size, block_off + 8) != (long) block_size) {
        free(buf);
        return 0;
    }

    u8 read_pos = 0;
    u8 payload_limit = block_size - 24; // Exclude magic footer & size2
    u8 fold = 0;

    while (read_pos + 12 <= payload_limit) {
        u8 pair_size = read_u8_le(buf + read_pos);
        u4 id = read_u4_le(buf + read_pos + 8);
        if (pair_size < 4 || read_pos + 8 + pair_size > payload_limit) break;

        // V2 (0x7109871a) or V3 (0xf05368c0) ID
        if (id == 0x7109871a || id == 0xf05368c0) {
            const u1 *val = buf + read_pos + 12;
            size_t val_len = (size_t) (pair_size - 4);
            if (val_len > 8) {
                // Signer sequence -> Signer -> SignedData -> Certificates -> Cert
                u4 offset = 4; // Skip sequence length
                if (offset + 4 <= val_len) {
                    u4 signer_len = read_u4_le(val + offset);
                    offset += 4;
                    if (offset + signer_len <= val_len && signer_len > 8) {
                        u4 signed_data_len = read_u4_le(val + offset);
                        offset += 4;
                        if (offset + signed_data_len <= val_len && signed_data_len > 8) {
                            u4 digests_len = read_u4_le(val + offset);
                            offset += 4 + digests_len;
                            if (offset + 4 <= val_len) {
                                u4 certs_len = read_u4_le(val + offset);
                                offset += 4;
                                if (offset + 4 <= val_len) {
                                    u4 cert_len = read_u4_le(val + offset);
                                    offset += 4;
                                    if (offset + cert_len <= val_len && cert_len > 0) {
                                        const u1 *cert_bytes = val + offset;
                                        for (u4 i = 0; i < cert_len; i++) {
                                            fold = (fold << 7) | (fold >> 57);
                                            fold ^= (u8) cert_bytes[i];
                                        }
                                        free(buf);
                                        return fold;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        read_pos += 8 + pair_size;
    }
    free(buf);
    return 0;
}

#define SIG_STATUS_DISABLED 0u
#define SIG_STATUS_MATCHED 1u
#define SIG_STATUS_NO_BASE_APK 2u
#define SIG_STATUS_PARSE_FAILED 3u

// Must match VmKeyConfig.deriveBindingKey / DISABLED_FOLD / FAILURE_FOLD.
#define DISABLED_FOLD 0x6a09e667f3bcc909ULL
#define FAILURE_FOLD  0xbb67ae8584caa73bULL
#define ZERO_KEY_FALLBACK 0xd6e8feb86659fd93ULL

static u8 mix64(u8 value) {
    value = (value ^ (value >> 30)) * 0xbf58476d1ce4e5b9ULL;
    value = (value ^ (value >> 27)) * 0x94d049bb133111ebULL;
    return value ^ (value >> 31);
}

static u8 salt64(int i) {
    const u4 lo[4] = {SIG_SALT_0_LO, SIG_SALT_1_LO, SIG_SALT_2_LO, SIG_SALT_3_LO};
    const u4 hi[4] = {SIG_SALT_0_HI, SIG_SALT_1_HI, SIG_SALT_2_HI, SIG_SALT_3_HI};
    return ((u8) hi[i] << 32) | (u8) lo[i];
}

static u8 derive_binding_key(u8 signer_fold) {
    u8 value = mix64(signer_fold ^ salt64(0));
    value = mix64(value + salt64(1));
    value ^= (salt64(2) << 17) | (salt64(2) >> 47);
    value = mix64(value + salt64(3));
    return value != 0 ? value : ZERO_KEY_FALLBACK;
}

u8 compute_runtime_key(void) {
    if (SIGNATURE_BINDING_ENABLED == 0u) {
        return derive_binding_key(DISABLED_FOLD);
    }
    char pkg[256];
    if (!read_pkg(pkg, sizeof(pkg))) {
        return derive_binding_key(FAILURE_FOLD);
    }
    char apk[512];
    if (!find_base_apk_from_self(apk, sizeof(apk))
            && !find_base_apk(pkg, apk, sizeof(apk))) {
        return derive_binding_key(FAILURE_FOLD);
    }
    int fd = sc_openat(apk);
    if (fd < 0) {
        return derive_binding_key(FAILURE_FOLD);
    }
    long sz = sc_size(fd);
    if (sz < 100) {
        sc_close(fd);
        return derive_binding_key(FAILURE_FOLD);
    }
    long eocd = find_eocd(fd, sz);
    if (eocd < 0) {
        sc_close(fd);
        return derive_binding_key(FAILURE_FOLD);
    }
    long block_off = 0;
    u8 block_sz = 0;
    if (!find_sig_block(fd, eocd, &block_off, &block_sz)) {
        sc_close(fd);
        return derive_binding_key(FAILURE_FOLD);
    }
    u8 fold = parse_cert_fold(fd, block_off, block_sz);
    sc_close(fd);
    if (fold == 0) {
        return derive_binding_key(FAILURE_FOLD);
    }
    return derive_binding_key(fold);
}

std::atomic<u8> g_cached_key{0};
std::atomic<bool> g_key_initialized{false};

} // namespace

extern "C" bool vm_find_base_apk_path(char *path, size_t pathSize) {
    if (find_base_apk_from_self(path, pathSize)) return true;
    char packageName[256];
    return read_pkg(packageName, sizeof(packageName))
            && find_base_apk(packageName, path, pathSize);
}

extern "C" u8 vm_sig_key(void) {
    if (g_key_initialized.load(std::memory_order_acquire)) {
        return g_cached_key.load(std::memory_order_relaxed);
    }
    u8 k = compute_runtime_key();
    g_cached_key.store(k, std::memory_order_relaxed);
    g_key_initialized.store(true, std::memory_order_release);
    return k;
}

extern "C" void vm_get_kdf_root(u1 out[32]) {
    for (int word = 0; word < 4; word++) {
        const u8 value = salt64(word);
        for (int byte = 0; byte < 8; byte++) {
            out[word * 8 + byte] = (u1) (value >> (byte * 8));
        }
    }
}
