//
// Runtime signature binding.
//
// Reads the running APK's own signing certificate straight from disk (APK
// Signing Block v2/v3), NOT via PackageManager (which is trivially spoofable).
// File I/O goes through raw syscalls to dodge libc open/read hooks. The signer
// cert DER is folded to 32 bits and XORed against a value baked in at protect
// time from the signing keystore. vm_sig_delta() returns 0 iff the running APK
// is signed with the original certificate; any re-sign yields a non-zero delta
// that is mixed into the bytecode decryption key, so a repacked app decrypts to
// garbage and dies with no branch to patch.
//
// Fail-open on any parse anomaly (delta 0) so a legitimately signed app is
// never bricked by a device/format edge case.
//
#include "Common.h"

#include <atomic>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>

// Baked at protect time (string-replaced). 0 == feature disabled.
#define EXPECTED_SIG_FOLD 0xCAFEF00Du /*SIGFOLD*/

namespace {

// --- raw syscall file I/O (resists libc PLT/inline hooks on open/read) ---
static int sc_openat(const char *path) {
    return (int) syscall(SYS_openat, AT_FDCWD, path, O_RDONLY, 0);
}
static long sc_pread(int fd, void *buf, unsigned long n, long off) {
    return syscall(SYS_pread64, fd, buf, n, off);
}
static long sc_read(int fd, void *buf, unsigned long n) {
    return syscall(SYS_read, fd, buf, n);
}
static void sc_close(int fd) { syscall(SYS_close, fd); }
static long sc_size(int fd) { return syscall(SYS_lseek, fd, 0, SEEK_END); }

// Read this process's base package name from /proc/self/cmdline.
static bool read_pkg(char *out, size_t outsz) {
    int fd = sc_openat("/proc/self/cmdline");
    if (fd < 0) return false;
    long r = sc_read(fd, out, (unsigned long) (outsz - 1));
    sc_close(fd);
    if (r <= 0) return false;
    out[r] = 0;
    for (long i = 0; i < r; i++) { if (out[i] == ':' || out[i] == 0) { out[i] = 0; break; } }
    return out[0] != 0;
}

// Locate this process's own base.apk via /proc/self/maps: a path that ends in
// .apk AND belongs to this package (contains the package name), so we never
// parse a framework/webview apk by mistake.
static bool find_base_apk(char *out, size_t outsz) {
    char pkg[256];
    bool havePkg = read_pkg(pkg, sizeof(pkg));
    int fd = sc_openat("/proc/self/maps");
    if (fd < 0) return false;
    char buf[8192];
    long r;
    bool found = false;
    char line[512];
    size_t ll = 0;
    while ((r = sc_read(fd, buf, sizeof(buf))) > 0) {
        for (long i = 0; i < r; i++) {
            char c = buf[i];
            if (c == '\n') {
                line[ll] = 0;
                char *slash = strchr(line, '/');
                if (slash) {
                    size_t pl = strlen(slash);
                    if (pl >= 4 && memcmp(slash + pl - 4, ".apk", 4) == 0) {
                        bool match = false;
                        if (havePkg && strstr(slash, pkg) != NULL) match = true;
                        else if (!havePkg && pl >= 8 && memcmp(slash + pl - 8, "base.apk", 8) == 0) match = true;
                        if (match && pl < outsz) { memcpy(out, slash, pl + 1); found = true; }
                    }
                }
                ll = 0;
                if (found) break;
            } else if (ll < sizeof(line) - 1) {
                line[ll++] = c;
            }
        }
        if (found) break;
    }
    sc_close(fd);
    return found;
}

static inline u4 rd_u32(const u1 *p) {
    return (u4) p[0] | ((u4) p[1] << 8) | ((u4) p[2] << 16) | ((u4) p[3] << 24);
}
static inline unsigned long long rd_u64(const u1 *p) {
    return (unsigned long long) rd_u32(p) | ((unsigned long long) rd_u32(p + 4) << 32);
}

static unsigned long long fnv1a64(const u1 *b, unsigned long n) {
    unsigned long long h = 0xcbf29ce484222325ULL;
    for (unsigned long i = 0; i < n; i++) { h ^= b[i]; h *= 0x100000001b3ULL; }
    return h;
}

// Parse APK -> first signer cert DER -> 32-bit fold. Returns false on any anomaly.
static bool compute_runtime_fold(u4 *out_fold) {
    char apk[1024];
    if (!find_base_apk(apk, sizeof(apk))) return false;
    int fd = sc_openat(apk);
    if (fd < 0) return false;

    bool ok = false;
    long fsize = sc_size(fd);
    do {
        if (fsize < 100) break;

        // EOCD: scan the tail for signature 0x06054b50
        long tail = fsize < 65600 ? fsize : 65600;
        u1 *tbuf = (u1 *) malloc((size_t) tail);
        if (!tbuf) break;
        if (sc_pread(fd, tbuf, (unsigned long) tail, fsize - tail) != tail) { free(tbuf); break; }
        long eocd = -1;
        for (long i = tail - 22; i >= 0; i--) {
            if (tbuf[i] == 0x50 && tbuf[i + 1] == 0x4b && tbuf[i + 2] == 0x05 && tbuf[i + 3] == 0x06) { eocd = i; break; }
        }
        if (eocd < 0) { free(tbuf); break; }
        u4 cd_off = rd_u32(tbuf + eocd + 16);
        free(tbuf);
        if (cd_off < 32 || cd_off > (u4) fsize) break;

        // Signing block footer: [u64 size][16-byte magic] ending right before CD
        u1 foot[24];
        if (sc_pread(fd, foot, 24, (long) cd_off - 24) != 24) break;
        if (memcmp(foot + 8, "APK Sig Block 42", 16) != 0) break;
        unsigned long long blk_size = rd_u64(foot);
        if (blk_size < 24 || blk_size > 8u * 1024 * 1024) break;
        long blk_start = (long) cd_off - (long) (blk_size + 8);
        if (blk_start < 0) break;

        unsigned long total = (unsigned long) (blk_size + 8);
        u1 *blk = (u1 *) malloc(total);
        if (!blk) break;
        if (sc_pread(fd, blk, total, blk_start) != (long) total) { free(blk); break; }
        if (rd_u64(blk) != blk_size) { free(blk); break; }

        // iterate id-value pairs: [u64 pairLen][u4 id][value]
        unsigned long p = 8, end = total - 24;
        long v_off = -1; unsigned long v_len = 0;
        while (p + 12 <= end) {
            unsigned long long pair = rd_u64(blk + p);
            if (pair < 4 || p + 8 + pair > total) break;
            u4 id = rd_u32(blk + p + 8);
            if (id == 0x7109871a) { v_off = (long) (p + 12); v_len = (unsigned long) (pair - 4); break; } // v2
            if (id == 0xf05368c0 && v_off < 0) { v_off = (long) (p + 12); v_len = (unsigned long) (pair - 4); } // v3 fallback
            p += 8 + pair;
        }
        if (v_off < 0) { free(blk); break; }

        // value: u4 signersLen; signer: u4 len; signedData: u4 len;
        //   digests: u4 len (skip); certs: u4 len; cert0: u4 len + DER
        unsigned long o = (unsigned long) v_off, vend = (unsigned long) v_off + v_len;
        if (o + 4 > vend) { free(blk); break; }
        o += 4;                                   // signers seq len
        if (o + 4 > vend) { free(blk); break; }
        o += 4;                                   // first signer len
        if (o + 4 > vend) { free(blk); break; }
        o += 4;                                   // signed data len
        if (o + 4 > vend) { free(blk); break; }
        u4 digs = rd_u32(blk + o); o += 4 + digs; // skip digests
        if (o + 4 > vend) { free(blk); break; }
        o += 4;                                   // certs seq len
        if (o + 4 > vend) { free(blk); break; }
        u4 cert_len = rd_u32(blk + o); o += 4;
        if (cert_len < 4 || o + cert_len > vend || o + cert_len > total) { free(blk); break; }

        unsigned long long h = fnv1a64(blk + o, cert_len);
        *out_fold = (u4) ((h >> 32) ^ (h & 0xffffffff));
        ok = true;
        free(blk);
    } while (0);

    sc_close(fd);
    return ok;
}

std::atomic<int> g_init{0};   // 0=uncomputed 1=ready
std::atomic<u4> g_delta{0};

} // namespace

extern "C" u4 vm_sig_delta(void) {
    if (EXPECTED_SIG_FOLD == 0u || EXPECTED_SIG_FOLD == 0xCAFEF00Du) return 0u; // disabled or unreplaced
    if (g_init.load(std::memory_order_acquire)) return g_delta.load(std::memory_order_relaxed);
    u4 fold = 0;
    u4 delta = 0;
    if (compute_runtime_fold(&fold)) {
        delta = fold ^ (u4) EXPECTED_SIG_FOLD;           // 0 iff original signer
    } else {
        delta = 0;                                       // fail-open on parse anomaly
    }
    g_delta.store(delta, std::memory_order_relaxed);
    g_init.store(1, std::memory_order_release);
    return delta;
}
