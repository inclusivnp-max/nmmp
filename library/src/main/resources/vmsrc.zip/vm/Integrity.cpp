// ELF segment checksum validation.
#include "Common.h"
#include "vm.h"

#include <atomic>
#include <cerrno>
#include <cstring>
#include <link.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

// Compatibility macros for syscall numbers across NDK unified headers & ABIs (ARM32/ARM64/x86/x86_64)
#ifndef SYS_mprotect
  #ifdef __NR_mprotect
    #define SYS_mprotect __NR_mprotect
  #else
    #define SYS_mprotect 125
  #endif
#endif

#ifndef SYS_clock_gettime
  #ifdef __NR_clock_gettime
    #define SYS_clock_gettime __NR_clock_gettime
  #else
    #define SYS_clock_gettime 113
  #endif
#endif

#ifndef SYS_gettid
  #ifdef __NR_gettid
    #define SYS_gettid __NR_gettid
  #else
    #define SYS_gettid 178
  #endif
#endif

namespace {

__attribute__((used, section(".data.wexhash" /*WEX_HASH_SECTION*/), aligned(16384)))
u1 EXPECTED_TEXT_HASH_PAGE[16384] = {
        0x71, 0x3c, 0xa9, 0x52, 0xe6, 0x18, 0x4d, 0xbf,
        0x90, 0x27, 0x65, 0xda, 0x43, 0xbc, 0x0f, 0x81,
        0x5e, 0xd4, 0x39, 0xa7, 0xc2, 0x68, 0xf1, 0x0b,
        0x96, 0x54, 0x2d, 0xe3, 0x7a, 0xc8, 0x11, 0x6f
};

#define EXPECTED_TEXT_HASH EXPECTED_TEXT_HASH_PAGE
constexpr size_t TEXT_HASH_SIZE = 32;

struct Sha256 {
    u4 h[8];
    u8 bits;
    u1 block[64];
    size_t used;
};

constexpr u4 K[64] = {
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

static inline u4 rotr(u4 x, unsigned n) { return (x >> n) | (x << (32 - n)); }

static void sha_transform(Sha256 *s, const u1 *block) {
    u4 w[64];
    for (int i = 0; i < 16; i++) {
        const u1 *p = block + i * 4;
        w[i] = ((u4) p[0] << 24) | ((u4) p[1] << 16) | ((u4) p[2] << 8) | p[3];
    }
    for (int i = 16; i < 64; i++) {
        const u4 a = w[i - 15], b = w[i - 2];
        const u4 s0 = rotr(a, 7) ^ rotr(a, 18) ^ (a >> 3);
        const u4 s1 = rotr(b, 17) ^ rotr(b, 19) ^ (b >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    u4 a = s->h[0], b = s->h[1], c = s->h[2], d = s->h[3];
    u4 e = s->h[4], f = s->h[5], g = s->h[6], h = s->h[7];
    for (int i = 0; i < 64; i++) {
        const u4 s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const u4 ch = (e & f) ^ (~e & g);
        const u4 t1 = h + s1 + ch + K[i] + w[i];
        const u4 s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const u4 maj = (a & b) ^ (a & c) ^ (b & c);
        const u4 t2 = s0 + maj;
        h = g; g = f; f = e; e = d + t1;
        d = c; c = b; b = a; a = t1 + t2;
    }
    s->h[0] += a; s->h[1] += b; s->h[2] += c; s->h[3] += d;
    s->h[4] += e; s->h[5] += f; s->h[6] += g; s->h[7] += h;
}

static void sha_init(Sha256 *s) {
    const u4 initial[8] = {
            0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
            0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    };
    memcpy(s->h, initial, sizeof(initial));
    s->bits = 0;
    s->used = 0;
}

static void sha_update(Sha256 *s, const u1 *data, size_t size) {
    s->bits += (u8) size * 8u;
    while (size != 0) {
        const size_t space = sizeof(s->block) - s->used;
        const size_t take = size < space ? size : space;
        memcpy(s->block + s->used, data, take);
        s->used += take;
        data += take;
        size -= take;
        if (s->used == sizeof(s->block)) {
            sha_transform(s, s->block);
            s->used = 0;
        }
    }
}

static void sha_final(Sha256 *s, u1 out[32]) {
    s->block[s->used++] = 0x80;
    if (s->used > 56) {
        while (s->used < 64) s->block[s->used++] = 0;
        sha_transform(s, s->block);
        s->used = 0;
    }
    while (s->used < 56) s->block[s->used++] = 0;
    for (int i = 7; i >= 0; i--) s->block[s->used++] = (u1) (s->bits >> (i * 8));
    sha_transform(s, s->block);
    for (int i = 0; i < 8; i++) {
        out[i * 4] = (u1) (s->h[i] >> 24);
        out[i * 4 + 1] = (u1) (s->h[i] >> 16);
        out[i * 4 + 2] = (u1) (s->h[i] >> 8);
        out[i * 4 + 3] = (u1) s->h[i];
    }
}

struct HashSearch {
    uintptr_t self;
    u1 digest[32];
    bool found;
};

static int hash_module(struct dl_phdr_info *info, size_t, void *opaque) {
    auto *search = reinterpret_cast<HashSearch *>(opaque);
    bool owns_self = false;
    for (ElfW(Half) i = 0; i < info->dlpi_phnum; i++) {
        const ElfW(Phdr) &ph = info->dlpi_phdr[i];
        if (ph.p_type != PT_LOAD) continue;
        const uintptr_t begin = (uintptr_t) info->dlpi_addr + ph.p_vaddr;
        if (search->self >= begin && search->self < begin + ph.p_memsz) {
            owns_self = true;
            break;
        }
    }
    if (!owns_self) return 0;

    Sha256 sha{};
    sha_init(&sha);
    for (ElfW(Half) i = 0; i < info->dlpi_phnum; i++) {
        const ElfW(Phdr) &ph = info->dlpi_phdr[i];
        if (ph.p_type == PT_LOAD && (ph.p_flags & PF_X) != 0 && ph.p_filesz != 0) {
            const auto *segment = reinterpret_cast<const u1 *>(info->dlpi_addr + ph.p_vaddr);
            sha_update(&sha, segment, (size_t) ph.p_filesz);
        }
    }
    sha_final(&sha, search->digest);
    search->found = true;
    return 1;
}

static u8 digest_delta(const u1 actual[32], const u1 expected[32]) {
    u8 delta = 0;
    for (int i = 0; i < 32; i++) {
        delta ^= (u8) (actual[i] ^ expected[i]) << ((i & 7) * 8);
        delta = (delta << 9) | (delta >> 55);
    }
    return delta == 0 ? 0x91e10da5c79e7b1dULL : delta;
}

std::atomic<u8> g_integrity_delta{0};
std::atomic<int> g_hash_page_protected{0};
std::atomic<int> g_integrity_worker_started{0};

static void protect_expected_hash(void) {
    int expected = 0;
    if (g_hash_page_protected.compare_exchange_strong(expected, 1, std::memory_order_acq_rel)) {
        syscall(SYS_mprotect, EXPECTED_TEXT_HASH_PAGE, sizeof(EXPECTED_TEXT_HASH_PAGE), PROT_READ);
    }
}

static unsigned integrity_noise(unsigned salt) {
    struct timespec ts{};
    syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &ts);
    unsigned x = (unsigned) ts.tv_nsec ^ (unsigned) ts.tv_sec ^
                 (unsigned) syscall(SYS_gettid) ^ salt;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

static void integrity_sleep_ms(unsigned delay_ms) {
    struct timespec delay{
            (time_t) (delay_ms / 1000u),
            (long) (delay_ms % 1000u) * 1000000L
    };
    while (nanosleep(&delay, &delay) != 0 && errno == EINTR) {}
}

static void *integrity_worker(void *) {
    // Keep full-text verification, but never charge its cost to a JNI/UI caller.
    (void) setpriority(PRIO_PROCESS, 0, 15);
    integrity_sleep_ms(900u + (integrity_noise(0) & 0x3ffu));
    for (;;) {
        if (g_integrity_delta.load(std::memory_order_acquire) != 0) return nullptr;
        const u8 delta = vm_verify_module(
                reinterpret_cast<const void *>(&vm_integrity_delta), EXPECTED_TEXT_HASH);
        if (delta != 0) {
            g_integrity_delta.store(delta, std::memory_order_release);
            return nullptr;
        }
        integrity_sleep_ms(30000u + (integrity_noise(1) & 0x1fffu));
    }
}

static void ensure_integrity_worker(void) {
    int expected = 0;
    if (!g_integrity_worker_started.compare_exchange_strong(
            expected, 1, std::memory_order_acq_rel, std::memory_order_acquire)) return;
    pthread_t worker;
    if (pthread_create(&worker, nullptr, integrity_worker, nullptr) == 0) {
        (void) pthread_detach(worker);
    } else {
        g_integrity_worker_started.store(0, std::memory_order_release);
    }
}

} // namespace

extern "C" __attribute__((visibility("default")))
u8 vm_verify_module(const void *anchor, const u1 expectedHash[32]) {
    HashSearch search{reinterpret_cast<uintptr_t>(anchor), {}, false};
    dl_iterate_phdr(hash_module, &search);
    if (!search.found) return 0x91e10da5c79e7b1dULL;
    if (memcmp(search.digest, expectedHash, TEXT_HASH_SIZE) == 0) return 0;
    return digest_delta(search.digest, expectedHash);
}

extern "C" u8 vm_integrity_delta(void) {
    protect_expected_hash();
    ensure_integrity_worker();
    return g_integrity_delta.load(std::memory_order_acquire);
}
