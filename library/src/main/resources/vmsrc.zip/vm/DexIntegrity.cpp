#include "Common.h"
#include "Crypto.h"
#include "vm.h"

#include <atomic>
#include <cerrno>
#include <fcntl.h>
#include <new>
#include <pthread.h>
#include <sys/resource.h>
#include <time.h>
#include <unistd.h>
#include <zlib.h>

extern "C" bool vm_find_base_apk_path(char *path, size_t pathSize);

namespace {

struct ExpectedDex {
    const char *name;
    u1 digest[32];
};

// WEX_DEX_HASHES_BEGIN
static const ExpectedDex EXPECTED_DEX[] = {
        {nullptr, {0}}
};
// Volatile prevents the empty template value from being folded into a literal
// divide-by-zero before writeDexIntegrityConfig() injects the final DEX table.
static const volatile size_t EXPECTED_DEX_COUNT = 0; /*WEX_DEX_COUNT*/
// WEX_DEX_HASHES_END

constexpr u4 EOCD_SIGNATURE = 0x06054b50u;
constexpr u4 CENTRAL_SIGNATURE = 0x02014b50u;
constexpr u4 LOCAL_SIGNATURE = 0x04034b50u;

static inline u2 read16(const u1 *p) {
    return (u2) p[0] | ((u2) p[1] << 8);
}

static inline u4 read32(const u1 *p) {
    return (u4) p[0] | ((u4) p[1] << 8) | ((u4) p[2] << 16) | ((u4) p[3] << 24);
}

static bool pread_all(int fd, void *output, size_t size, off_t offset) {
    auto *cursor = reinterpret_cast<u1 *>(output);
    while (size != 0) {
        const ssize_t count = pread(fd, cursor, size, offset);
        if (count <= 0) return false;
        cursor += count;
        offset += count;
        size -= (size_t) count;
    }
    return true;
}

static off_t file_size(int fd) {
    const off_t current = lseek(fd, 0, SEEK_CUR);
    const off_t size = lseek(fd, 0, SEEK_END);
    if (current >= 0) lseek(fd, current, SEEK_SET);
    return size;
}

struct CentralDirectory {
    off_t offset;
    u4 size;
    u2 entries;
};

static bool find_central_directory(int fd, CentralDirectory *result) {
    const off_t size = file_size(fd);
    if (size < 22) return false;
    const size_t tailSize = (size_t) (size < 65557 ? size : 65557);
    auto *tail = new (std::nothrow) u1[tailSize];
    if (tail == nullptr) return false;
    const off_t tailOffset = size - (off_t) tailSize;
    bool found = false;
    if (pread_all(fd, tail, tailSize, tailOffset)) {
        for (size_t pos = tailSize - 22;; pos--) {
            if (read32(tail + pos) == EOCD_SIGNATURE
                    && pos + 22u + read16(tail + pos + 20) == tailSize) {
                const u2 disk = read16(tail + pos + 4);
                const u2 centralDisk = read16(tail + pos + 6);
                const u2 entriesOnDisk = read16(tail + pos + 8);
                const u2 entries = read16(tail + pos + 10);
                const u4 centralSize = read32(tail + pos + 12);
                const u4 centralOffset = read32(tail + pos + 16);
                if (disk == 0 && centralDisk == 0 && entries == entriesOnDisk
                        && centralOffset <= (u8) size
                        && centralSize <= (u8) size - centralOffset) {
                    *result = {(off_t) centralOffset, centralSize, entries};
                    found = true;
                }
                break;
            }
            if (pos == 0) break;
        }
    }
    vm_secure_zero(tail, tailSize);
    delete[] tail;
    return found;
}

struct ZipEntry {
    u2 method;
    u4 compressedSize;
    u4 uncompressedSize;
    u4 localOffset;
};

static bool find_entry(int fd, const char *wanted, ZipEntry *result) {
    CentralDirectory central{};
    if (!find_central_directory(fd, &central)) return false;
    off_t cursor = central.offset;
    const off_t end = central.offset + central.size;
    u1 header[46];
    for (u2 entry = 0; entry < central.entries && cursor + 46 <= end; entry++) {
        if (!pread_all(fd, header, sizeof(header), cursor)
                || read32(header) != CENTRAL_SIGNATURE) return false;
        const u2 nameSize = read16(header + 28);
        const u2 extraSize = read16(header + 30);
        const u2 commentSize = read16(header + 32);
        const off_t next = cursor + 46u + nameSize + extraSize + commentSize;
        if (next > end || nameSize == 0 || nameSize >= 128) return false;
        char name[128];
        if (!pread_all(fd, name, nameSize, cursor + 46)) return false;
        name[nameSize] = 0;
        if (strcmp(name, wanted) == 0) {
            result->method = read16(header + 10);
            result->compressedSize = read32(header + 20);
            result->uncompressedSize = read32(header + 24);
            result->localOffset = read32(header + 42);
            return true;
        }
        cursor = next;
    }
    return false;
}

static bool entry_data_offset(int fd, const ZipEntry &entry, off_t *offset) {
    u1 header[30];
    if (!pread_all(fd, header, sizeof(header), entry.localOffset)
            || read32(header) != LOCAL_SIGNATURE) return false;
    const u2 nameSize = read16(header + 26);
    const u2 extraSize = read16(header + 28);
    *offset = (off_t) entry.localOffset + 30u + nameSize + extraSize;
    return true;
}

static bool hash_stored(int fd, off_t offset, u4 size, u1 digest[32]) {
    VmSha256 sha{};
    vm_sha256_init(&sha);
    u1 buffer[16384];
    u4 remaining = size;
    while (remaining != 0) {
        const size_t count = remaining < sizeof(buffer) ? remaining : sizeof(buffer);
        if (!pread_all(fd, buffer, count, offset)) return false;
        vm_sha256_update(&sha, buffer, count);
        offset += (off_t) count;
        remaining -= (u4) count;
    }
    vm_sha256_final(&sha, digest);
    vm_secure_zero(buffer, sizeof(buffer));
    return true;
}

static bool hash_deflated(int fd, off_t offset, const ZipEntry &entry, u1 digest[32]) {
    z_stream stream{};
    if (inflateInit2(&stream, -MAX_WBITS) != Z_OK) return false;
    VmSha256 sha{};
    vm_sha256_init(&sha);
    u1 input[16384];
    u1 output[16384];
    u4 remaining = entry.compressedSize;
    u8 produced = 0;
    int status = Z_OK;
    bool valid = true;
    while (status != Z_STREAM_END && valid) {
        if (stream.avail_in == 0 && remaining != 0) {
            const size_t count = remaining < sizeof(input) ? remaining : sizeof(input);
            valid = pread_all(fd, input, count, offset);
            if (!valid) break;
            offset += (off_t) count;
            remaining -= (u4) count;
            stream.next_in = input;
            stream.avail_in = (uInt) count;
        }
        stream.next_out = output;
        stream.avail_out = sizeof(output);
        status = inflate(&stream, Z_NO_FLUSH);
        if (status != Z_OK && status != Z_STREAM_END) {
            valid = false;
            break;
        }
        const size_t count = sizeof(output) - stream.avail_out;
        if (count != 0) {
            vm_sha256_update(&sha, output, count);
            produced += count;
        }
        if (count == 0 && stream.avail_in == 0 && remaining == 0
                && status != Z_STREAM_END) valid = false;
    }
    if (valid && status == Z_STREAM_END && produced == entry.uncompressedSize) {
        vm_sha256_final(&sha, digest);
    } else {
        valid = false;
        vm_secure_zero(&sha, sizeof(sha));
    }
    inflateEnd(&stream);
    vm_secure_zero(input, sizeof(input));
    vm_secure_zero(output, sizeof(output));
    return valid;
}

static bool hash_dex_entry(const char *name, u1 digest[32]) {
    char apkPath[768];
    if (!vm_find_base_apk_path(apkPath, sizeof(apkPath))) return false;
    const int fd = open(apkPath, O_RDONLY | O_CLOEXEC);
    vm_secure_zero(apkPath, sizeof(apkPath));
    if (fd < 0) return false;
    ZipEntry entry{};
    off_t offset = 0;
    bool valid = find_entry(fd, name, &entry) && entry_data_offset(fd, entry, &offset);
    if (valid) {
        if (entry.method == 0) {
            valid = entry.compressedSize == entry.uncompressedSize
                    && hash_stored(fd, offset, entry.uncompressedSize, digest);
        } else if (entry.method == 8) {
            valid = hash_deflated(fd, offset, entry, digest);
        } else {
            valid = false;
        }
    }
    close(fd);
    return valid;
}

static u8 digest_delta(const u1 actual[32], const u1 expected[32], size_t index) {
    u8 delta = 0x243f6a8885a308d3ULL ^ (u8) index;
    for (unsigned i = 0; i < 32; i++) {
        delta ^= (u8) (actual[i] ^ expected[i]) << ((i & 7u) * 8u);
        delta = (delta << 11) | (delta >> 53);
    }
    return delta == 0 ? 0x13198a2e03707344ULL : delta;
}

std::atomic<u8> g_dex_delta{0};
std::atomic<int> g_dex_worker_started{0};

static void dex_sleep_ms(unsigned delay_ms) {
    struct timespec delay{
            (time_t) (delay_ms / 1000u),
            (long) (delay_ms % 1000u) * 1000000L
    };
    while (nanosleep(&delay, &delay) != 0 && errno == EINTR) {}
}

static void *dex_integrity_worker(void *) {
    // DEX inflate+SHA may touch tens of megabytes. Run the complete cycle on a
    // low-priority worker instead of periodically stalling whichever JNI call
    // happened to cross a call-count threshold.
    (void) setpriority(PRIO_PROCESS, 0, 15);
    dex_sleep_ms(1800u);
    const size_t expectedDexCount = EXPECTED_DEX_COUNT;
    for (;;) {
        for (size_t index = 0; index < expectedDexCount; index++) {
            if (g_dex_delta.load(std::memory_order_acquire) != 0) return nullptr;
            u1 actual[32]{};
            if (!hash_dex_entry(EXPECTED_DEX[index].name, actual)
                    || memcmp(actual, EXPECTED_DEX[index].digest, sizeof(actual)) != 0) {
                const u8 delta = digest_delta(actual, EXPECTED_DEX[index].digest, index);
                g_dex_delta.store(delta, std::memory_order_release);
                vm_secure_zero(actual, sizeof(actual));
                return nullptr;
            }
            vm_secure_zero(actual, sizeof(actual));
            if (index + 1u < expectedDexCount) dex_sleep_ms(750u);
        }
        dex_sleep_ms(30000u);
    }
}

static void ensure_dex_integrity_worker(void) {
    int expected = 0;
    if (!g_dex_worker_started.compare_exchange_strong(
            expected, 1, std::memory_order_acq_rel, std::memory_order_acquire)) return;
    pthread_t worker;
    if (pthread_create(&worker, nullptr, dex_integrity_worker, nullptr) == 0) {
        (void) pthread_detach(worker);
    } else {
        g_dex_worker_started.store(0, std::memory_order_release);
    }
}

} // namespace

extern "C" u8 vm_dex_integrity_delta(void) {
    if (EXPECTED_DEX_COUNT != 0) ensure_dex_integrity_worker();
    return g_dex_delta.load(std::memory_order_acquire);
}
