//
// Anti-analysis guard.
//
// High-confidence detection of a hostile runtime (frida agent/gadget or an
// attached tracer that also shows frida worker threads). The response is
// deliberately NOT an immediate crash: once tainted, after a randomized delay
// the guard intermittently corrupts a virtualized method's return value, so
// the failure surfaces far from the check and looks like a flaky bug rather
// than a tripped tripwire. High threshold keeps false positives near zero.
//
#include <jni.h>
#include "Common.h"

#include <atomic>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>

namespace {

std::atomic<unsigned> g_calls{0};
std::atomic<int> g_taint{0};
std::atomic<int> g_countdown{0};

// frida artefacts as they appear in /proc/self/maps
const char *const MAP_SIGS[] = {"frida", "linjector", "gadget", "gum-js", "re.frida", nullptr};
// frida worker thread names in /proc/self/task/*/comm
const char *const THREAD_SIGS[] = {"gum-js", "frida", "pool-frida", "pool-spawn", nullptr};

bool contains_any(const char *buf, size_t n, const char *const *sigs) {
    for (int i = 0; sigs[i]; i++) {
        const size_t sl = strlen(sigs[i]);
        if (sl == 0 || sl > n) continue;
        for (size_t p = 0; p + sl <= n; p++) {
            if (buf[p] == sigs[i][0] && memcmp(buf + p, sigs[i], sl) == 0) return true;
        }
    }
    return false;
}

bool scan_maps() {
    int fd = open("/proc/self/maps", O_RDONLY);
    if (fd < 0) return false;
    char buf[8192];
    size_t carry = 0;          // bytes kept from previous chunk (straddle guard)
    bool hit = false;
    ssize_t r;
    while ((r = read(fd, buf + carry, sizeof(buf) - carry)) > 0) {
        const size_t total = carry + (size_t) r;
        if (contains_any(buf, total, MAP_SIGS)) { hit = true; break; }
        const size_t keep = total < 15 ? total : 15;
        memmove(buf, buf + total - keep, keep);
        carry = keep;
    }
    close(fd);
    return hit;
}

int tracer_pid() {
    int fd = open("/proc/self/status", O_RDONLY);
    if (fd < 0) return 0;
    char buf[4096];
    ssize_t r = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (r <= 0) return 0;
    buf[r] = 0;
    const char *p = strstr(buf, "TracerPid:");
    if (!p) return 0;
    p += 10;
    while (*p == ' ' || *p == '\t') p++;
    return atoi(p);
}

bool task_has_frida_thread() {
    DIR *d = opendir("/proc/self/task");
    if (!d) return false;
    bool hit = false;
    struct dirent *e;
    while ((e = readdir(d)) != nullptr) {
        if (e->d_name[0] == '.') continue;
        char path[280];
        snprintf(path, sizeof(path), "/proc/self/task/%s/comm", e->d_name);
        int fd = open(path, O_RDONLY);
        if (fd < 0) continue;
        char comm[64];
        ssize_t r = read(fd, comm, sizeof(comm) - 1);
        close(fd);
        if (r > 0) {
            comm[r] = 0;
            if (contains_any(comm, (size_t) r, THREAD_SIGS)) { hit = true; break; }
        }
    }
    closedir(d);
    return hit;
}

bool hostile_env() {
    if (scan_maps()) return true;                          // frida agent/gadget mapped
    if (tracer_pid() != 0 && task_has_frida_thread()) return true; // traced + frida threads
    return false;
}

} // namespace

extern "C" void vm_guard_apply(jvalue *rv) {
    const unsigned c = g_calls.fetch_add(1, std::memory_order_relaxed);

    // Throttled, high-confidence probe (~every 4096 returns; stops once tainted).
    if (!g_taint.load(std::memory_order_relaxed) && (c & 0xFFF) == 0) {
        if (hostile_env()) {
            g_taint.store(1, std::memory_order_relaxed);
            g_countdown.store(80 + (int) (c & 0x7F), std::memory_order_relaxed);
        }
    }

    if (g_taint.load(std::memory_order_relaxed)) {
        const int cd = g_countdown.fetch_sub(1, std::memory_order_relaxed);
        // After the delay, corrupt ~1 in 4 returns: flaky, not dead, hard to localize.
        if (cd <= 0 && (c & 3) == 0 && rv != nullptr) {
            rv->j ^= 0x0000000000010001LL; // bit0 (bool/ptr) + bit16 (int) -> wrong result / delayed crash
        }
    }
}
