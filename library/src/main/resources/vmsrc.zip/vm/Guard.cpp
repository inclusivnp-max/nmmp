//
// Runtime environment validation.
//
// Periodic health checks for execution context consistency:
// memory layout, timing variance, device classification, and binary integrity.
//
#include <jni.h>
#include "Common.h"

#include <atomic>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/syscall.h>
#include <stdint.h>

// Compatibility macros for syscall numbers across NDK unified headers & ABIs (ARM32/ARM64/x86/x86_64)
#ifndef SYS_openat
  #ifdef __NR_openat
    #define SYS_openat __NR_openat
  #else
    #define SYS_openat 56
  #endif
#endif

#ifndef SYS_read
  #ifdef __NR_read
    #define SYS_read __NR_read
  #else
    #define SYS_read 63
  #endif
#endif

#ifndef SYS_close
  #ifdef __NR_close
    #define SYS_close __NR_close
  #else
    #define SYS_close 57
  #endif
#endif

#ifndef SYS_clock_gettime
  #ifdef __NR_clock_gettime
    #define SYS_clock_gettime __NR_clock_gettime
  #else
    #define SYS_clock_gettime 113
  #endif
#endif

#ifndef SYS_gettid
  #ifdef __NR_gettid
    #define SYS_gettid __NR_gettid
  #else
    #define SYS_gettid 178
  #endif
#endif

#ifndef SYS_getdents64
  #if defined(__NR_getdents64)
    #define SYS_getdents64 __NR_getdents64
  #elif defined(__aarch64__)
    #define SYS_getdents64 61
  #elif defined(__arm__)
    #define SYS_getdents64 217
  #elif defined(__i386__)
    #define SYS_getdents64 220
  #elif defined(__x86_64__)
    #define SYS_getdents64 217
  #else
    #define SYS_getdents64 61
  #endif
#endif

extern "C" u8 vm_integrity_delta(void);

namespace {

std::atomic<unsigned> g_calls{0};
std::atomic<int> g_taint{0};
std::atomic<int> g_countdown{0};
std::atomic<unsigned> g_next_probe{0};
std::atomic<unsigned> g_response_phase{0};

struct EncodedSig {
    const u1 *bytes;
    u1 length;
};

// WEX_SIGS_BEGIN
// Per-build encoded runtime indicators.
const u1 S0[] = {0xc3, 0xd7, 0xcc, 0xc1, 0xc4};
const u1 S1[] = {0xc9, 0xcc, 0xcb, 0xcf, 0xc0, 0xc6, 0xd1, 0xca, 0xd7};
const u1 S2[] = {0xc2, 0xc4, 0xc1, 0xc2, 0xc0, 0xd1};
const u1 S3[] = {0xc2, 0xd0, 0xc8, 0x88, 0xcf, 0xd6};
const u1 S4[] = {0xd7, 0xc0, 0x8b, 0xc3, 0xd7, 0xcc, 0xc1, 0xc4};
const u1 S5[] = {0xd5, 0xca, 0xca, 0xc9, 0x88, 0xc3, 0xd7, 0xcc, 0xc1, 0xc4};
const u1 S6[] = {0xd5, 0xca, 0xca, 0xc9, 0x88, 0xd6, 0xd5, 0xc4, 0xd2, 0xcb};
const u1 SC0[] = {0xe3, 0xca, 0xc9, 0xc4, 0xcb, 0xd1, 0xd6, 0xd1};
const u1 SC1[] = {0xd7, 0xc0, 0xcf, 0xc8, 0xd6, 0xd3};
const u1 SC2[] = {0xf0, 0xe8, 0xf5};
const u1 SC3[] = {0xd3, 0xc2, 0xca, 0xc7};
const u1 SC4[] = {0xed, 0xd0, 0xd4, 0xd5, 0xd7, 0xd3, 0xd2, 0xd4, 0xd6, 0xdc};
const u1 SD0[] = {0xd4, 0xd5, 0xd5, 0xd6, 0x88, 0x94};
const u1 SD1[] = {0xc0, 0xcf, 0xc4, 0xd7, 0xca, 0xc9, 0xc4, 0xc2, 0xca, 0xca, 0xd8, 0x88, 0xd2, 0xc0, 0xd7, 0xc4, 0xd7, 0xd0, 0xd7, 0xd5, 0x88, 0xd5, 0xca, 0xc9, 0xc4, 0xcb, 0xd1, 0xd6, 0xd1};
const u1 SD2[] = {0xc0, 0xcf, 0xc4, 0xd7, 0xca, 0xc9, 0xc4, 0xc2, 0xca, 0xca, 0xd8, 0x88, 0xd2, 0xc0, 0xd7, 0xc4, 0xd7, 0xd0, 0xd7, 0xd5, 0x88, 0xd7, 0xc0, 0xcf, 0xc8, 0xd6, 0xd3};
const u1 SD3[] = {0xd3, 0xc2, 0xca, 0xc7, 0xd1, 0xcb};
// WEX_SIGS_END

// WEX_EPATHS_BEGIN
// Per-build encoded emulator device paths.
const u1 EP0[]  = {0x8b, 0xc4, 0xd5, 0xd3, 0x88, 0xd4, 0xd5, 0xd5, 0xd6, 0x88, 0xd4, 0xd7, 0xd4, 0xd5};
const u1 EP1[]  = {0x8b, 0xc4, 0xd5, 0xd3, 0x88, 0xd5, 0xca, 0xc9, 0xc4, 0xcb, 0xd1, 0xd6, 0xd1, 0x88, 0xd4, 0xd7, 0xd4, 0xd5};
const u1 EP2[]  = {0x8b, 0xc4, 0xd5, 0xd3, 0x88, 0xd5, 0xca, 0xc9, 0xc4, 0xcb, 0xd1, 0xd6, 0xd1, 0x88, 0xd1, 0xd0, 0xcf, 0xc8};
const u1 EP3[]  = {0x8b, 0xc4, 0xd5, 0xd3, 0x88, 0xd1, 0xca, 0xc8, 0xc8, 0xd5, 0xd8, 0x88, 0xd4, 0xd5, 0xd5, 0xd6, 0xc4};
const u1 EP4[]  = {0x8b, 0xd1, 0xd0, 0xd1, 0xd8, 0xd5, 0xd5, 0x88, 0xc9, 0xd7, 0xc2, 0x88, 0xc9, 0xd7, 0xc8, 0x88, 0xc4, 0xd3, 0xc9, 0x5a, 0xd1, 0xc0, 0xc9, 0xca, 0xc8, 0x88, 0xc4, 0xd5, 0xc2, 0xd6, 0x88, 0xd4, 0xd5, 0xd5, 0xd6, 0x88, 0xd1, 0xca};
const u1 EP5[]  = {0x8b, 0xd1, 0xd0, 0xd1, 0xd8, 0xd5, 0xd5, 0x88, 0xc9, 0xd7, 0xc2, 0x36, 0x34, 0x88, 0xc9, 0xd7, 0xc2, 0x88, 0xc4, 0xd3, 0xc9, 0x5a, 0xd1, 0xc0, 0xc9, 0xca, 0xc8, 0x88, 0xc4, 0xd5, 0xc2, 0xd6, 0x88, 0xd4, 0xd5, 0xd5, 0xd6, 0x88, 0xd1, 0xca};
const u1 EP6[]  = {0x8b, 0xd1, 0xd0, 0xd1, 0x88, 0xd4, 0xd5, 0xd5, 0xd6, 0x88, 0xd8, 0xd7, 0xc0, 0xc8, 0xd5};
const u1 EP7[]  = {0x8b, 0xd1, 0xd0, 0xd1, 0xd5, 0xd5, 0x88, 0xc2, 0xd7, 0xcf, 0x88, 0xd4, 0xd5, 0xd5, 0xd6, 0x88, 0xd4, 0xd7, 0xca, 0xd4, 0xd1};
const u1 EP8[]  = {0x8b, 0xc4, 0xd5, 0xd3, 0x88, 0xd3, 0xc2, 0xca, 0xc7, 0xd5, 0xd6, 0xd5, 0xd1, 0xd8};
const u1 EP9[]  = {0x8b, 0xc4, 0xd5, 0xd3, 0x88, 0xd3, 0xc2, 0xca, 0xc7, 0xd6, 0xd1, 0xd5, 0xd7};
const u1 EP10[] = {0x8b, 0xc4, 0xd5, 0xd3, 0x88, 0xd1, 0xca, 0xc8, 0xc8, 0xd5, 0xd8, 0x88, 0xd5, 0xd5, 0xcf, 0xd0, 0xc4};
const u1 EP11[] = {0x8b, 0xc4, 0xd5, 0xd3, 0x88, 0xd1, 0xca, 0xc8, 0xc8, 0xd5, 0xd8, 0x88, 0xc2, 0xc0, 0xd1, 0xd5, 0xc2, 0xc0, 0xcf, 0x88, 0xd5, 0xd5, 0xcf, 0xd0, 0xc4};
const u1 EP12[] = {0x8b, 0xd1, 0xd0, 0xd1, 0xd5, 0xd5, 0x88, 0xc2, 0xd7, 0xcf, 0x88, 0xd5, 0xd5, 0xcf, 0xd0, 0xd0, 0xd1, 0xd8, 0xcf, 0xd7, 0xcf, 0x88, 0xd3, 0xc2, 0xca, 0xc7, 0x88, 0xd1, 0xcb};
const u1 EP13[] = {0x8b, 0xd1, 0xd0, 0xd1, 0x88, 0xd5, 0xca, 0xc4, 0xd6, 0xc9, 0xd5, 0xd5, 0x88, 0xd4, 0xd5, 0xd5, 0xd6, 0x88, 0xd8, 0xd7, 0xc0, 0xc8, 0xd5};
const u1 EP14[] = {0x8b, 0xd1, 0xd0, 0xd1, 0x88, 0xd5, 0xca, 0xc4, 0xd6, 0xc9, 0xd5, 0xd5, 0x88, 0xd3, 0xc2, 0xca, 0xc7, 0xd5, 0xd6, 0xd5, 0xd1, 0xd8};
const u1 EP15[] = {0x8b, 0xc4, 0xd5, 0xd3, 0x88, 0xd8, 0xd8, 0xd0, 0x53, 0x90};
// WEX_EPATHS_END

#define SIG_XOR_KEY 0xA5u /*WXSIGKEY*/

const EncodedSig MAP_SIGS[] = {
        {S0, sizeof(S0)}, {S1, sizeof(S1)}, {S2, sizeof(S2)},
        {S3, sizeof(S3)}, {S4, sizeof(S4)}, {nullptr, 0}
};
const EncodedSig THREAD_SIGS[] = {
        {S3, sizeof(S3)}, {S0, sizeof(S0)}, {S5, sizeof(S5)},
        {S6, sizeof(S6)}, {nullptr, 0}
};
const EncodedSig CPUINFO_SIGS[] = {
        {SC0, sizeof(SC0)}, {SC1, sizeof(SC1)}, {SC2, sizeof(SC2)},
        {SC3, sizeof(SC3)}, {SC4, sizeof(SC4)}, {nullptr, 0}
};
const EncodedSig CMDLINE_SIGS[] = {
        {SD0, sizeof(SD0)}, {SD1, sizeof(SD1)},
        {SD2, sizeof(SD2)}, {SD3, sizeof(SD3)}, {nullptr, 0}
};
struct EncodedPath { const u1 *bytes; u1 len; };
static const EncodedPath EMULATOR_PATHS[] = {
        {EP0, sizeof(EP0)}, {EP1, sizeof(EP1)}, {EP2, sizeof(EP2)}, {EP3, sizeof(EP3)},
        {EP4, sizeof(EP4)}, {EP5, sizeof(EP5)}, {EP6, sizeof(EP6)}, {EP7, sizeof(EP7)},
        {EP8, sizeof(EP8)}, {EP9, sizeof(EP9)}, {EP10, sizeof(EP10)}, {EP11, sizeof(EP11)},
        {EP12, sizeof(EP12)}, {EP13, sizeof(EP13)}, {EP14, sizeof(EP14)}, {EP15, sizeof(EP15)},
        {nullptr, 0}
};

static int sc_openat(const char *path, int flags = O_RDONLY) {
    return (int) syscall(SYS_openat, AT_FDCWD, path, flags, 0);
}
static long sc_read(int fd, void *buf, unsigned long n) {
    return syscall(SYS_read, fd, buf, n);
}
static void sc_close(int fd) { syscall(SYS_close, fd); }

static unsigned jitter(unsigned salt) {
    struct timespec ts{};
    syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &ts);
    unsigned x = (unsigned) ts.tv_nsec ^ (unsigned) ts.tv_sec ^
                 (unsigned) syscall(SYS_gettid) ^ salt;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    return x;
}

static uint64_t read_cntvct() {
    uint64_t val = 0;
#if defined(__aarch64__)
    asm volatile("mrs %0, cntvct_el0" : "=r"(val));
#else
    struct timespec ts{};
    syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &ts);
    val = (uint64_t)ts.tv_sec * 1000000000ULL + ts.tv_nsec;
#endif
    return val;
}

static bool check_hypervisor_timing() {
    uint64_t start = read_cntvct();
    volatile int dummy = 0;
    // Multi-phase loop with unpredictable data dependence to force CPU execution cycle measurement
    for (int i = 0; i < 600; i++) {
        dummy += (i ^ (i * 3)) + ((i & 1) ? (dummy * 7) : (i >> 2));
    }
    uint64_t end = read_cntvct();
    uint64_t diff = end - start;

    if (diff > 1500000ULL) {
        return true;
    }

    // Secondary dual-timestamp check for clock drift / VM pause injection
    uint64_t t1 = read_cntvct();
    struct timespec ts1{}, ts2{};
    syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &ts1);
    for (int j = 0; j < 200; j++) {
        dummy ^= (j * 13) + dummy;
    }
    syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &ts2);
    uint64_t t2 = read_cntvct();

    uint64_t nsec_diff = (uint64_t)(ts2.tv_sec - ts1.tv_sec) * 1000000000ULL + (ts2.tv_nsec - ts1.tv_nsec);
    uint64_t cnt_diff = t2 - t1;

    if (nsec_diff > 5000000ULL || cnt_diff > 2000000ULL) {
        return true;
    }

    return false;
}

bool contains_any(const char *buf, size_t n, const EncodedSig *sigs) {
    for (int i = 0; sigs[i].bytes != nullptr; i++) {
        const size_t sl = sigs[i].length;
        if (sl == 0 || sl > n) continue;
        for (size_t p = 0; p + sl <= n; p++) {
            size_t j = 0;
            while (j < sl && ((u1) buf[p + j] ^ SIG_XOR_KEY) == sigs[i].bytes[j]) j++;
            if (j == sl) return true;
        }
    }
    return false;
}

static bool check_emulator_devices() {
    char path[80];
    for (int i = 0; EMULATOR_PATHS[i].bytes != nullptr; i++) {
        const u1 len = EMULATOR_PATHS[i].len;
        for (u1 j = 0; j < len && j < 79; j++) path[j] = EMULATOR_PATHS[i].bytes[j] ^ SIG_XOR_KEY;
        path[len] = '\0';
        int fd = sc_openat(path);
        if (fd >= 0) { sc_close(fd); return true; }
    }
    int fd_cpu = sc_openat("/proc/cpuinfo");
    if (fd_cpu >= 0) {
        char buf[1024]; long r = sc_read(fd_cpu, buf, sizeof(buf) - 1); sc_close(fd_cpu);
        if (r > 0) { buf[r] = '\0'; if (contains_any(buf, (size_t) r, CPUINFO_SIGS)) return true; }
    }
    int fd_cmd = sc_openat("/proc/cmdline");
    if (fd_cmd >= 0) {
        char buf[512]; long r = sc_read(fd_cmd, buf, sizeof(buf) - 1); sc_close(fd_cmd);
        if (r > 0) { buf[r] = '\0'; if (contains_any(buf, (size_t) r, CMDLINE_SIGS)) return true; }
    }
    return false;
}

bool audit_address_space() {
    int fd = sc_openat("/proc/self/maps");
    if (fd < 0) return false;
    char buf[1024];
    size_t pending = 0;
    bool hit = false;
    long r;
    while (!hit && (r = sc_read(fd, buf + pending, sizeof(buf) - 1 - pending)) > 0) {
        const size_t total = pending + (size_t) r;
        buf[total] = '\0';
        size_t line_start = 0;
        for (size_t i = 0; i < total; i++) {
            if (buf[i] == '\n') {
                buf[i] = '\0';
                if (contains_any(buf + line_start, i - line_start, MAP_SIGS)) {
                    hit = true;
                    break;
                }
                line_start = i + 1;
            }
        }
        if (line_start < total) {
            pending = total - line_start;
            memmove(buf, buf + line_start, pending);
        } else {
            pending = 0;
        }
    }
    sc_close(fd);
    return hit;
}

bool audit_thread_names() {
    struct LinuxDirent64 {
        unsigned long long ino;
        long long off;
        unsigned short reclen;
        unsigned char type;
        char name[1];
    };
    int dir = sc_openat("/proc/self/task", O_RDONLY | O_DIRECTORY);
    if (dir < 0) return false;
    bool hit = false;
    char entries[4096];
    long count;
    while (!hit && (count = syscall(SYS_getdents64, dir, entries, sizeof(entries))) > 0) {
        long pos = 0;
        while (pos < count) {
            const auto *entry = reinterpret_cast<const LinuxDirent64 *>(entries + pos);
            if (entry->reclen == 0 || pos + entry->reclen > count) break;
            if (entry->name[0] != '.') {
                char path[280];
                const int written = snprintf(path, sizeof(path), "/proc/self/task/%s/comm", entry->name);
                if (written > 0 && (size_t) written < sizeof(path)) {
                    int fd = sc_openat(path);
                    if (fd >= 0) {
                        char comm[64];
                        const long r = sc_read(fd, comm, sizeof(comm));
                        sc_close(fd);
                        if (r > 0 && contains_any(comm, (size_t) r, THREAD_SIGS)) {
                            hit = true;
                            break;
                        }
                    }
                }
            }
            pos += entry->reclen;
        }
    }
    sc_close(dir);
    return hit;
}

bool rt_tamper_detected() {
    // Emulator/device classification is diagnostic only.  Poisoning arbitrary
    // VM return values for a virtual device corrupts valid application state.
    // Active response remains tied to concrete instrumentation or integrity hits.
    if (audit_address_space()) return true;
    if (audit_thread_names()) return true;
    if (vm_integrity_delta() != 0) return true;
    return false;
}

} // namespace

extern "C" void vm_guard_apply(jvalue *rv, char return_type) {
    const unsigned c = g_calls.fetch_add(1, std::memory_order_relaxed);

    if (c == 0) {
        const unsigned seed = jitter(0x57584744u);
        g_next_probe.store(32u + (seed & 0x7Fu), std::memory_order_relaxed);
    }

    if (!g_taint.load(std::memory_order_relaxed)) {
        unsigned next = g_next_probe.load(std::memory_order_relaxed);
        if (c >= next) {
            const unsigned noise = jitter(c);
            const unsigned scheduled = c + 2048u + (noise & 0xFFFu);
            if (g_next_probe.compare_exchange_strong(next, scheduled, std::memory_order_relaxed)) {
                if (rt_tamper_detected()) {
                    g_response_phase.store((noise >> 12) & 3u, std::memory_order_relaxed);
                    g_countdown.store(48 + (int) ((noise >> 16) & 0xFFu), std::memory_order_relaxed);
                    g_taint.store(1, std::memory_order_release);
                }
            }
        }
    }

    if (g_taint.load(std::memory_order_acquire)) {
        const int cd = g_countdown.fetch_sub(1, std::memory_order_relaxed);
        const unsigned phase = g_response_phase.load(std::memory_order_relaxed);
        if (cd <= 0 && ((c + phase) & 3u) == 0 && rv != nullptr) {
            switch (return_type) {
                case 'Z': rv->z ^= 1u; break;
                case 'B': rv->b ^= 1; break;
                case 'S': rv->s ^= 0x101; break;
                case 'C': rv->c ^= 0x101u; break;
                case 'I': rv->i ^= 0x00010001; break;
                case 'J': rv->j ^= 0x0000000100010001LL; break;
                case 'F': {
                    union { float f; u4 i; } u{rv->f};
                    u.i ^= 0x7f800001u;
                    rv->f = u.f;
                    break;
                }
                case 'D': {
                    union { double d; u8 i; } u{rv->d};
                    u.i ^= 0x7ff0000000000001ULL;
                    rv->d = u.d;
                    break;
                }
                default: break;
            }
        }
    }
}
