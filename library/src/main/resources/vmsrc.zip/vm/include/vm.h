//
// Created by mao on 20-8-11.
//

#ifndef DEX_EDITOR_VM_H
#define DEX_EDITOR_VM_H

#include <jni.h>
#include "Common.h"

#define vm_aead_open WX_API_0
#define vmInterpret WX_API_1
#define vm_verify_module WX_API_5

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    u2 classIdx;
    char type;
    jfieldID fieldId;
} vmField;

typedef struct {
    u2 classIdx;
    const char *shorty;  //包含返回类型及参数类型,用于确定使用什么样的方法调用
    jmethodID methodId;
} vmMethod;

typedef struct {
    u4 start;
    u4 size;
    u8 contextTag;
    u8 siteMaterial;
    u1 nonce[12];
    u1 tag[16];
} vmFlowBlock;

typedef struct {
    const u1 *encrypted;
    const vmFlowBlock *blocks;
    u4 blockCount;
} vmFlow;

typedef struct {
    const u2 *insns;             //指令
    const u4 insnsSize;          //指令大小
    const char returnType;       // JNI return descriptor's first character
    regptr_t *regs;                    //寄存器
    u1 *reg_flags;               //寄存器数据类型标记,主要标记是否为对象
    const u1 *triesHandlers;     //异常表
    const vmFlow *flow;          //optional independently encrypted basic blocks
    const u8 integrityDelta;     //generated-library self-integrity contribution
} vmCode;

typedef struct {

    const vmField *(*dvmResolveField)(JNIEnv *env, u4 idx, bool isStatic);

    const vmMethod *(*dvmResolveMethod)(JNIEnv *env, u4 idx, bool isStatic);

    //从类型常量池取得类型名
    const char *(*dvmResolveTypeUtf)(JNIEnv *env, u4 idx);

    //直接返回jclass对象,本地引用需要释放引用
    jclass (*dvmResolveClass)(JNIEnv *env, u4 idx);

    //根据类型名得到class
    jclass (*dvmFindClass)(JNIEnv *env, const char *type);

    //const_string指令加载的字符串对象
    jstring (*dvmConstantString)(JNIEnv *env, u4 idx);

} vmResolver;


u8 vm_sig_key(void);

u8 vm_integrity_delta(void);

u8 vm_dex_integrity_delta(void);

void vm_guard_apply(jvalue *rv, char returnType);

// Authenticated in-place/open operation for generated instruction streams,
// FlowLock blocks, try tables and resolver pools.
bool vm_aead_open(u1 *dst, const u1 *src, u4 sizeBytes,
                  const u1 nonce[12], const u1 expectedTag[16],
                  u4 domain, u8 contextTag, u8 siteMaterial);

// Hash executable PT_LOAD segments for the module containing anchor.
u8 vm_verify_module(const void *anchor, const u1 expectedHash[32]);

jvalue vmInterpret(
        JNIEnv *env,
        const vmCode *code,
        const vmResolver *dvmResolver
);

#ifdef __cplusplus
}
#endif

#endif //DEX_EDITOR_VM_H
