#ifndef NMMP_VM_CRYPTO_H
#define NMMP_VM_CRYPTO_H

#include <stddef.h>
#include "Common.h"

typedef struct {
    u4 h[8];
    u8 bits;
    u1 block[64];
    size_t used;
} VmSha256;

void vm_sha256_init(VmSha256 *state);
void vm_sha256_update(VmSha256 *state, const void *data, size_t size);
void vm_sha256_final(VmSha256 *state, u1 out[32]);
void vm_sha256(const void *data, size_t size, u1 out[32]);
void vm_secure_zero(void *data, size_t size);

#endif
